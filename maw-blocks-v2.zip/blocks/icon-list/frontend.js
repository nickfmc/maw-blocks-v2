/**
 * Icon List Block Frontend
 * 
 * No JavaScript needed for this block - it's pure HTML/CSS
 */

// This block doesn't require frontend JavaScript
// but the file is needed for the build system consistency